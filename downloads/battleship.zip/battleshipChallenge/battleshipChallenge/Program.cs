﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleshipChallenge
{
    internal class Program
    {
        /* Chase Redland
         * 4/17/26
         * Solo battleship!
         */

        static void Main(string[] args)
        {
            Random random = new Random();
            char[,] board = new char[10, 10];
            char[,] playerBoard = new char[10, 10];
            int curRow, curCol;
            int countShip = 17;
            int score = 0;

            GenerateBoard(board);
            GenerateBoard(playerBoard);
            MakeShip(board, 5, 'A', random); // Letters are for debugging purposes
            MakeShip(board, 4, 'B', random);
            MakeShip(board, 3, 'S', random);
            MakeShip(board, 3, 'C', random);
            MakeShip(board, 2, 'D', random);

            Console.Write("- BattleShip -\n");
            PrintBoard(playerBoard);

            do
            {
                PlayerInput(out curRow, out curCol);
                Shoot(ref countShip, ref score, curRow, curCol, board, playerBoard);
                PrintBoard(playerBoard);
            }
            while(countShip > 0 && score < 64);

            if (score < 64)
            {
                Console.WriteLine("\n\nYou win!!!");
                Console.WriteLine("Your score is " + score + " (Lower is better)");
            }
            else
            {
                Console.WriteLine("\n\nYou lose :(");
            }

            Console.ReadKey();
        }

        /// <summary>
        /// Create an empty water board
        /// </summary>
        /// <param name="board">Board</param>
        static void GenerateBoard(char[,] board)
        {
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for(int j = 0; j < board.GetLength(1); j++)
                {
                    board[i,j] = '~';
                }
            }
        }

        /// <summary>
        /// Tries repeatedly to place a ship
        /// </summary>
        /// <param name="board">Ship board</param>
        /// <param name="length">Length of ship</param>
        /// <param name="letter">Ship letter (debug)</param>
        /// <param name="random">Randomizer</param>
        static void MakeShip(char[,] board, int length, char letter, Random random)
        {
            int i, j;
            bool isFound = false;

            do
            {
                do
                {
                    i = random.Next(0, 8);
                    j = random.Next(0, 8);
                }
                while (board[i, j] != '~');

                bool isVertical = random.Next(0, 2) == 1 ? true : false;

                if (isVertical && i + length < board.GetLength(0))
                {
                    bool canPlace = true;
                    for (int k = 0, tempI = i; k < length; k++, tempI++)
                    {
                        if (board[tempI, j] != '~') canPlace = false;
                    }
                    if (canPlace)
                    {
                        isFound = true;
                        for (int k = 0; k < length; k++, i++)
                        {
                            board[i, j] = letter;
                        }
                    }
                }
                if (!isVertical && j + length < board.GetLength(1))
                {
                    bool canPlace = true;
                    for (int k = 0, tempJ = j; k < length; k++, tempJ++)
                    {
                        if (board[i, tempJ] != '~') canPlace = false;
                    }
                    if (canPlace)
                    {
                        isFound = true;
                        for (int k = 0; k < length; k++, j++)
                        {
                            board[i, j] = letter;
                        }
                    }
                }

            }
            while (!isFound);
        }

        /// <summary>
        /// Prints a given board
        /// </summary>
        /// <param name="board">Given board</param>
        static void PrintBoard(char[,] board)
        {
            Console.WriteLine("\n  1 2 3 4 5 6 7 8 9 10");
            for (int i = 0; i < board.GetLength(0); i++)
            {
                Console.Write($"{Convert.ToChar(65 + i), 1} ");
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    Console.Write(board[i,j] + " ");
                }
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Gets player input until valid
        /// </summary>
        /// <param name="row">Row</param>
        /// <param name="col">Column</param>
        static void PlayerInput(out int row, out int col)
        {
            Console.WriteLine("\nSelect a coordinate to fire on!");
            do
            {
                Console.Write("Enter the coordinate A-J 1-10 (ex. B8): ");

                string temp = Console.ReadLine();
                string tempRow = temp.Substring(0, 1);
                char charRow = Convert.ToChar(tempRow.ToUpper());
                row = Convert.ToInt32(charRow) - 65;
                
                string tempCol = temp.Substring(1);
                col = Convert.ToInt32(tempCol) - 1;
            }
            while (col < 0 || col >= 10 || row < 0 || row >= 10);
        }

        /// <summary>
        /// Attempts to shoot, and then updates boards
        /// </summary>
        /// <param name="countShip">Lower countship if hit</param>
        /// <param name="row">Given row</param>
        /// <param name="col">Given column</param>
        /// <param name="board">Update ship board</param>
        /// <param name="playerBoard">Update player board</param>
        static void Shoot(ref int countShip, ref int score, int row, int col, char[,] board, char[,] playerBoard)
        {
            if (playerBoard[row, col] == 'O' || playerBoard[row, col] == 'X')
            {
                Console.Write("\nAlready fired there, try again!");
            }
            else if (board[row, col] != '~')
            {
                Console.Write("\nHit!");
                playerBoard[row, col] = 'X';
                countShip--;
                score++;
            }
            else if (board[row, col] == '~')
            {
                Console.Write("\nMiss!");
                playerBoard[row, col] = 'O';
                score++;
            }
        }
    }
}
