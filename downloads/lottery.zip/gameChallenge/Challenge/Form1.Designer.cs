﻿namespace Challenge
{
    partial class RetroRevival
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RetroRevival));
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_ps2Price = new System.Windows.Forms.Label();
            this.lbl_ps2 = new System.Windows.Forms.Label();
            this.lbl_gameCube = new System.Windows.Forms.Label();
            this.lbl_gmCubePrice = new System.Windows.Forms.Label();
            this.lbl_dreamCast = new System.Windows.Forms.Label();
            this.lbl_dreamCastPrice = new System.Windows.Forms.Label();
            this.btnGameCube = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnPS2 = new System.Windows.Forms.Button();
            this.txtAmtGameCube = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAmtPS2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAmtDreamCast = new System.Windows.Forms.TextBox();
            this.btnDreamCast = new System.Windows.Forms.Button();
            this.lbl2 = new System.Windows.Forms.Label();
            this.txtAmtMarioKart = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.txtAmtPikmin = new System.Windows.Forms.TextBox();
            this.btnResidentEvil = new System.Windows.Forms.Button();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.txtAmtFinalFantasy = new System.Windows.Forms.TextBox();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.txtAmtSilentHill = new System.Windows.Forms.TextBox();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.txtResidentEvil = new System.Windows.Forms.TextBox();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.txtSonic = new System.Windows.Forms.TextBox();
            this.lbl9 = new System.Windows.Forms.Label();
            this.picResidentEvil = new System.Windows.Forms.PictureBox();
            this.picSonic = new System.Windows.Forms.PictureBox();
            this.picFinalFantasy = new System.Windows.Forms.PictureBox();
            this.picSilentHill = new System.Windows.Forms.PictureBox();
            this.picPikmin = new System.Windows.Forms.PictureBox();
            this.picMarioKart = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblReceipt = new System.Windows.Forms.Label();
            this.btnSonic = new System.Windows.Forms.Button();
            this.btnFinalFantasy = new System.Windows.Forms.Button();
            this.btnSilentHill = new System.Windows.Forms.Button();
            this.btnPikmin = new System.Windows.Forms.Button();
            this.btnMarioKart = new System.Windows.Forms.Button();
            this.btnNewOrder = new System.Windows.Forms.Button();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picResidentEvil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSonic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFinalFantasy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSilentHill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPikmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMarioKart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 24F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label1.Location = new System.Drawing.Point(569, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Retro Revival";
            // 
            // lbl_ps2Price
            // 
            this.lbl_ps2Price.AutoSize = true;
            this.lbl_ps2Price.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl_ps2Price.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl_ps2Price.Location = new System.Drawing.Point(1163, 208);
            this.lbl_ps2Price.Name = "lbl_ps2Price";
            this.lbl_ps2Price.Size = new System.Drawing.Size(64, 17);
            this.lbl_ps2Price.TabIndex = 5;
            this.lbl_ps2Price.Text = "$150.99";
            // 
            // lbl_ps2
            // 
            this.lbl_ps2.AutoSize = true;
            this.lbl_ps2.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_ps2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl_ps2.Location = new System.Drawing.Point(1162, 92);
            this.lbl_ps2.Name = "lbl_ps2";
            this.lbl_ps2.Size = new System.Drawing.Size(138, 18);
            this.lbl_ps2.TabIndex = 4;
            this.lbl_ps2.Text = "Playstation 2";
            // 
            // lbl_gameCube
            // 
            this.lbl_gameCube.AutoEllipsis = true;
            this.lbl_gameCube.AutoSize = true;
            this.lbl_gameCube.BackColor = System.Drawing.Color.Transparent;
            this.lbl_gameCube.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_gameCube.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl_gameCube.Location = new System.Drawing.Point(708, 92);
            this.lbl_gameCube.Name = "lbl_gameCube";
            this.lbl_gameCube.Size = new System.Drawing.Size(88, 18);
            this.lbl_gameCube.TabIndex = 6;
            this.lbl_gameCube.Text = "GameCube";
            // 
            // lbl_gmCubePrice
            // 
            this.lbl_gmCubePrice.AutoSize = true;
            this.lbl_gmCubePrice.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl_gmCubePrice.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl_gmCubePrice.Location = new System.Drawing.Point(707, 208);
            this.lbl_gmCubePrice.Name = "lbl_gmCubePrice";
            this.lbl_gmCubePrice.Size = new System.Drawing.Size(64, 17);
            this.lbl_gmCubePrice.TabIndex = 7;
            this.lbl_gmCubePrice.Text = "$175.99";
            // 
            // lbl_dreamCast
            // 
            this.lbl_dreamCast.AutoSize = true;
            this.lbl_dreamCast.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_dreamCast.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl_dreamCast.Location = new System.Drawing.Point(232, 92);
            this.lbl_dreamCast.Name = "lbl_dreamCast";
            this.lbl_dreamCast.Size = new System.Drawing.Size(98, 18);
            this.lbl_dreamCast.TabIndex = 8;
            this.lbl_dreamCast.Text = "DreamCast";
            // 
            // lbl_dreamCastPrice
            // 
            this.lbl_dreamCastPrice.AutoSize = true;
            this.lbl_dreamCastPrice.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl_dreamCastPrice.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl_dreamCastPrice.Location = new System.Drawing.Point(236, 208);
            this.lbl_dreamCastPrice.Name = "lbl_dreamCastPrice";
            this.lbl_dreamCastPrice.Size = new System.Drawing.Size(64, 17);
            this.lbl_dreamCastPrice.TabIndex = 9;
            this.lbl_dreamCastPrice.Text = "$200.99";
            // 
            // btnGameCube
            // 
            this.btnGameCube.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnGameCube.Location = new System.Drawing.Point(707, 271);
            this.btnGameCube.Name = "btnGameCube";
            this.btnGameCube.Size = new System.Drawing.Size(124, 27);
            this.btnGameCube.TabIndex = 11;
            this.btnGameCube.Text = "Purchase";
            this.btnGameCube.UseVisualStyleBackColor = true;
            this.btnGameCube.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(515, 351);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(375, 256);
            this.label2.TabIndex = 12;
            this.label2.Text = resources.GetString("label2.Text");
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnPS2
            // 
            this.btnPS2.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnPS2.Location = new System.Drawing.Point(1166, 271);
            this.btnPS2.Name = "btnPS2";
            this.btnPS2.Size = new System.Drawing.Size(120, 27);
            this.btnPS2.TabIndex = 13;
            this.btnPS2.Text = "Purchase";
            this.btnPS2.UseVisualStyleBackColor = true;
            this.btnPS2.Click += new System.EventHandler(this.btnPS2_Click);
            // 
            // txtAmtGameCube
            // 
            this.txtAmtGameCube.Location = new System.Drawing.Point(707, 245);
            this.txtAmtGameCube.Name = "txtAmtGameCube";
            this.txtAmtGameCube.Size = new System.Drawing.Size(120, 20);
            this.txtAmtGameCube.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Courier New", 10F);
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label4.Location = new System.Drawing.Point(708, 225);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 17);
            this.label4.TabIndex = 16;
            this.label4.Text = "Amount:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Courier New", 10F);
            this.label5.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label5.Location = new System.Drawing.Point(1168, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 17);
            this.label5.TabIndex = 18;
            this.label5.Text = "Amount:";
            // 
            // txtAmtPS2
            // 
            this.txtAmtPS2.Location = new System.Drawing.Point(1167, 245);
            this.txtAmtPS2.Name = "txtAmtPS2";
            this.txtAmtPS2.Size = new System.Drawing.Size(120, 20);
            this.txtAmtPS2.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Courier New", 10F);
            this.label6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label6.Location = new System.Drawing.Point(236, 226);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 17);
            this.label6.TabIndex = 21;
            this.label6.Text = "Amount:";
            // 
            // txtAmtDreamCast
            // 
            this.txtAmtDreamCast.Location = new System.Drawing.Point(235, 246);
            this.txtAmtDreamCast.Name = "txtAmtDreamCast";
            this.txtAmtDreamCast.Size = new System.Drawing.Size(120, 20);
            this.txtAmtDreamCast.TabIndex = 20;
            // 
            // btnDreamCast
            // 
            this.btnDreamCast.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnDreamCast.Location = new System.Drawing.Point(234, 272);
            this.btnDreamCast.Name = "btnDreamCast";
            this.btnDreamCast.Size = new System.Drawing.Size(120, 27);
            this.btnDreamCast.TabIndex = 19;
            this.btnDreamCast.Text = "Purchase";
            this.btnDreamCast.UseVisualStyleBackColor = true;
            this.btnDreamCast.Click += new System.EventHandler(this.btnDreamCast_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl2.Location = new System.Drawing.Point(964, 563);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(64, 17);
            this.lbl2.TabIndex = 28;
            this.lbl2.Text = "Amount:";
            this.lbl2.Visible = false;
            // 
            // txtAmtMarioKart
            // 
            this.txtAmtMarioKart.Location = new System.Drawing.Point(1034, 561);
            this.txtAmtMarioKart.Name = "txtAmtMarioKart";
            this.txtAmtMarioKart.Size = new System.Drawing.Size(102, 20);
            this.txtAmtMarioKart.TabIndex = 27;
            this.txtAmtMarioKart.Visible = false;
            // 
            // lbl1
            // 
            this.lbl1.AutoEllipsis = true;
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.Color.Transparent;
            this.lbl1.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold);
            this.lbl1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl1.Location = new System.Drawing.Point(982, 533);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(151, 16);
            this.lbl1.TabIndex = 24;
            this.lbl1.Text = "MarioKart - $64.99";
            this.lbl1.Visible = false;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl4.Location = new System.Drawing.Point(1176, 565);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(64, 17);
            this.lbl4.TabIndex = 33;
            this.lbl4.Text = "Amount:";
            this.lbl4.Visible = false;
            // 
            // txtAmtPikmin
            // 
            this.txtAmtPikmin.Location = new System.Drawing.Point(1246, 563);
            this.txtAmtPikmin.Name = "txtAmtPikmin";
            this.txtAmtPikmin.Size = new System.Drawing.Size(102, 20);
            this.txtAmtPikmin.TabIndex = 32;
            this.txtAmtPikmin.Visible = false;
            // 
            // btnResidentEvil
            // 
            this.btnResidentEvil.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnResidentEvil.Location = new System.Drawing.Point(1197, 587);
            this.btnResidentEvil.Name = "btnResidentEvil";
            this.btnResidentEvil.Size = new System.Drawing.Size(124, 27);
            this.btnResidentEvil.TabIndex = 31;
            this.btnResidentEvil.Text = "Add to Order";
            this.btnResidentEvil.UseVisualStyleBackColor = true;
            this.btnResidentEvil.Visible = false;
            this.btnResidentEvil.Click += new System.EventHandler(this.btnGamePurchase_Click);
            // 
            // lbl3
            // 
            this.lbl3.AutoEllipsis = true;
            this.lbl3.AutoSize = true;
            this.lbl3.BackColor = System.Drawing.Color.Transparent;
            this.lbl3.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold);
            this.lbl3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl3.Location = new System.Drawing.Point(1194, 533);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(127, 16);
            this.lbl3.TabIndex = 29;
            this.lbl3.Text = "Pikmin - $29.99";
            this.lbl3.Visible = false;
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl8.Location = new System.Drawing.Point(1181, 566);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(64, 17);
            this.lbl8.TabIndex = 43;
            this.lbl8.Text = "Amount:";
            this.lbl8.Visible = false;
            // 
            // txtAmtFinalFantasy
            // 
            this.txtAmtFinalFantasy.Location = new System.Drawing.Point(1246, 563);
            this.txtAmtFinalFantasy.Name = "txtAmtFinalFantasy";
            this.txtAmtFinalFantasy.Size = new System.Drawing.Size(102, 20);
            this.txtAmtFinalFantasy.TabIndex = 42;
            this.txtAmtFinalFantasy.Visible = false;
            // 
            // lbl7
            // 
            this.lbl7.AutoEllipsis = true;
            this.lbl7.AutoSize = true;
            this.lbl7.BackColor = System.Drawing.Color.Transparent;
            this.lbl7.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold);
            this.lbl7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl7.Location = new System.Drawing.Point(1167, 533);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(183, 16);
            this.lbl7.TabIndex = 40;
            this.lbl7.Text = "Final Fantasy - $14.99";
            this.lbl7.Visible = false;
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl6.Location = new System.Drawing.Point(969, 564);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(64, 17);
            this.lbl6.TabIndex = 39;
            this.lbl6.Text = "Amount:";
            this.lbl6.Visible = false;
            // 
            // txtAmtSilentHill
            // 
            this.txtAmtSilentHill.Location = new System.Drawing.Point(1039, 562);
            this.txtAmtSilentHill.Name = "txtAmtSilentHill";
            this.txtAmtSilentHill.Size = new System.Drawing.Size(102, 20);
            this.txtAmtSilentHill.TabIndex = 38;
            this.txtAmtSilentHill.Visible = false;
            // 
            // lbl5
            // 
            this.lbl5.AutoEllipsis = true;
            this.lbl5.AutoSize = true;
            this.lbl5.BackColor = System.Drawing.Color.Transparent;
            this.lbl5.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold);
            this.lbl5.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl5.Location = new System.Drawing.Point(969, 533);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(167, 16);
            this.lbl5.TabIndex = 36;
            this.lbl5.Text = "Silent Hill - $34.99";
            this.lbl5.Visible = false;
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl12.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl12.Location = new System.Drawing.Point(1181, 566);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(64, 17);
            this.lbl12.TabIndex = 53;
            this.lbl12.Text = "Amount:";
            this.lbl12.Visible = false;
            // 
            // txtResidentEvil
            // 
            this.txtResidentEvil.Location = new System.Drawing.Point(1246, 563);
            this.txtResidentEvil.Name = "txtResidentEvil";
            this.txtResidentEvil.Size = new System.Drawing.Size(102, 20);
            this.txtResidentEvil.TabIndex = 52;
            this.txtResidentEvil.Visible = false;
            // 
            // lbl11
            // 
            this.lbl11.AutoEllipsis = true;
            this.lbl11.AutoSize = true;
            this.lbl11.BackColor = System.Drawing.Color.Transparent;
            this.lbl11.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold);
            this.lbl11.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl11.Location = new System.Drawing.Point(1167, 533);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(183, 16);
            this.lbl11.TabIndex = 50;
            this.lbl11.Text = "Resident Evil - $14.99";
            this.lbl11.Visible = false;
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbl10.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl10.Location = new System.Drawing.Point(969, 564);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(64, 17);
            this.lbl10.TabIndex = 49;
            this.lbl10.Text = "Amount:";
            this.lbl10.Visible = false;
            // 
            // txtSonic
            // 
            this.txtSonic.Location = new System.Drawing.Point(1039, 562);
            this.txtSonic.Name = "txtSonic";
            this.txtSonic.Size = new System.Drawing.Size(102, 20);
            this.txtSonic.TabIndex = 48;
            this.txtSonic.Visible = false;
            // 
            // lbl9
            // 
            this.lbl9.AutoEllipsis = true;
            this.lbl9.AutoSize = true;
            this.lbl9.BackColor = System.Drawing.Color.Transparent;
            this.lbl9.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold);
            this.lbl9.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lbl9.Location = new System.Drawing.Point(990, 533);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(119, 16);
            this.lbl9.TabIndex = 46;
            this.lbl9.Text = "Sonic - $49.99";
            this.lbl9.Visible = false;
            // 
            // picResidentEvil
            // 
            this.picResidentEvil.Image = global::Challenge.Properties.Resources.images;
            this.picResidentEvil.Location = new System.Drawing.Point(1170, 351);
            this.picResidentEvil.Name = "picResidentEvil";
            this.picResidentEvil.Size = new System.Drawing.Size(178, 179);
            this.picResidentEvil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picResidentEvil.TabIndex = 45;
            this.picResidentEvil.TabStop = false;
            this.picResidentEvil.Visible = false;
            // 
            // picSonic
            // 
            this.picSonic.Image = global::Challenge.Properties.Resources.Sonic_Adventure_main_art;
            this.picSonic.Location = new System.Drawing.Point(958, 351);
            this.picSonic.Name = "picSonic";
            this.picSonic.Size = new System.Drawing.Size(178, 179);
            this.picSonic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSonic.TabIndex = 44;
            this.picSonic.TabStop = false;
            this.picSonic.Visible = false;
            // 
            // picFinalFantasy
            // 
            this.picFinalFantasy.Image = global::Challenge.Properties.Resources._6849433;
            this.picFinalFantasy.Location = new System.Drawing.Point(1170, 351);
            this.picFinalFantasy.Name = "picFinalFantasy";
            this.picFinalFantasy.Size = new System.Drawing.Size(178, 179);
            this.picFinalFantasy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFinalFantasy.TabIndex = 35;
            this.picFinalFantasy.TabStop = false;
            this.picFinalFantasy.Visible = false;
            // 
            // picSilentHill
            // 
            this.picSilentHill.Image = global::Challenge.Properties.Resources.IgwsFz9BiBrFvyV7pIWpoVgd;
            this.picSilentHill.Location = new System.Drawing.Point(958, 351);
            this.picSilentHill.Name = "picSilentHill";
            this.picSilentHill.Size = new System.Drawing.Size(178, 179);
            this.picSilentHill.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSilentHill.TabIndex = 34;
            this.picSilentHill.TabStop = false;
            this.picSilentHill.Visible = false;
            // 
            // picPikmin
            // 
            this.picPikmin.Image = global::Challenge.Properties.Resources.MV5BMWIzYThjMGQtNDYxMS00YjUwLTgwYzktNWIyYjA2NGY4NTg0XkEyXkFqcGc___V1_FMjpg_UX1000_;
            this.picPikmin.Location = new System.Drawing.Point(1170, 351);
            this.picPikmin.Name = "picPikmin";
            this.picPikmin.Size = new System.Drawing.Size(178, 179);
            this.picPikmin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picPikmin.TabIndex = 23;
            this.picPikmin.TabStop = false;
            this.picPikmin.Visible = false;
            // 
            // picMarioKart
            // 
            this.picMarioKart.Image = global::Challenge.Properties.Resources.images__1_;
            this.picMarioKart.Location = new System.Drawing.Point(958, 351);
            this.picMarioKart.Name = "picMarioKart";
            this.picMarioKart.Size = new System.Drawing.Size(178, 179);
            this.picMarioKart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picMarioKart.TabIndex = 22;
            this.picMarioKart.TabStop = false;
            this.picMarioKart.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Challenge.Properties.Resources.SEGA_Dreamcast_removebg_preview;
            this.pictureBox3.Location = new System.Drawing.Point(13, 92);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(213, 207);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Challenge.Properties.Resources.PS2_Versions_removebg_preview;
            this.pictureBox2.Location = new System.Drawing.Point(924, 92);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(233, 206);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Challenge.Properties.Resources._71ydg4MNj_L_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(438, 92);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(263, 206);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblReceipt
            // 
            this.lblReceipt.AutoSize = true;
            this.lblReceipt.Font = new System.Drawing.Font("Courier New", 10F);
            this.lblReceipt.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblReceipt.Location = new System.Drawing.Point(24, 364);
            this.lblReceipt.Name = "lblReceipt";
            this.lblReceipt.Size = new System.Drawing.Size(0, 17);
            this.lblReceipt.TabIndex = 54;
            // 
            // btnSonic
            // 
            this.btnSonic.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnSonic.Location = new System.Drawing.Point(993, 587);
            this.btnSonic.Name = "btnSonic";
            this.btnSonic.Size = new System.Drawing.Size(124, 27);
            this.btnSonic.TabIndex = 55;
            this.btnSonic.Text = "Add to Order";
            this.btnSonic.UseVisualStyleBackColor = true;
            this.btnSonic.Visible = false;
            this.btnSonic.Click += new System.EventHandler(this.btnSonic_Click);
            // 
            // btnFinalFantasy
            // 
            this.btnFinalFantasy.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnFinalFantasy.Location = new System.Drawing.Point(1197, 586);
            this.btnFinalFantasy.Name = "btnFinalFantasy";
            this.btnFinalFantasy.Size = new System.Drawing.Size(124, 27);
            this.btnFinalFantasy.TabIndex = 56;
            this.btnFinalFantasy.Text = "Add to Order";
            this.btnFinalFantasy.UseVisualStyleBackColor = true;
            this.btnFinalFantasy.Visible = false;
            this.btnFinalFantasy.Click += new System.EventHandler(this.btnFinalFantasy_Click);
            // 
            // btnSilentHill
            // 
            this.btnSilentHill.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnSilentHill.Location = new System.Drawing.Point(993, 588);
            this.btnSilentHill.Name = "btnSilentHill";
            this.btnSilentHill.Size = new System.Drawing.Size(124, 27);
            this.btnSilentHill.TabIndex = 57;
            this.btnSilentHill.Text = "Add to Order";
            this.btnSilentHill.UseVisualStyleBackColor = true;
            this.btnSilentHill.Visible = false;
            this.btnSilentHill.Click += new System.EventHandler(this.btnSilentHill_Click);
            // 
            // btnPikmin
            // 
            this.btnPikmin.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnPikmin.Location = new System.Drawing.Point(1197, 586);
            this.btnPikmin.Name = "btnPikmin";
            this.btnPikmin.Size = new System.Drawing.Size(124, 27);
            this.btnPikmin.TabIndex = 58;
            this.btnPikmin.Text = "Add to Order";
            this.btnPikmin.UseVisualStyleBackColor = true;
            this.btnPikmin.Visible = false;
            this.btnPikmin.Click += new System.EventHandler(this.btnPikmin_Click);
            // 
            // btnMarioKart
            // 
            this.btnMarioKart.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnMarioKart.Location = new System.Drawing.Point(993, 588);
            this.btnMarioKart.Name = "btnMarioKart";
            this.btnMarioKart.Size = new System.Drawing.Size(124, 27);
            this.btnMarioKart.TabIndex = 59;
            this.btnMarioKart.Text = "Add to Order";
            this.btnMarioKart.UseVisualStyleBackColor = true;
            this.btnMarioKart.Visible = false;
            this.btnMarioKart.Click += new System.EventHandler(this.btnMarioKart_Click);
            // 
            // btnNewOrder
            // 
            this.btnNewOrder.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnNewOrder.Location = new System.Drawing.Point(211, 586);
            this.btnNewOrder.Name = "btnNewOrder";
            this.btnNewOrder.Size = new System.Drawing.Size(174, 27);
            this.btnNewOrder.TabIndex = 60;
            this.btnNewOrder.Text = "Start a New Order";
            this.btnNewOrder.UseVisualStyleBackColor = true;
            this.btnNewOrder.Visible = false;
            this.btnNewOrder.Click += new System.EventHandler(this.btnNewOrder_Click);
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.btnPlaceOrder.Location = new System.Drawing.Point(27, 586);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(178, 27);
            this.btnPlaceOrder.TabIndex = 61;
            this.btnPlaceOrder.Text = "Place Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = true;
            this.btnPlaceOrder.Visible = false;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Courier New", 8F);
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(236, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 84);
            this.label3.TabIndex = 62;
            this.label3.Text = "A vibrant, arcade-style \r\nsystem perfect for quick \r\nbursts of fun with unique \r\n" +
    "interactive controllers that \r\nkids find fascinating.\r\n\r\n";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Courier New", 8F);
            this.label7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label7.Location = new System.Drawing.Point(708, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 84);
            this.label7.TabIndex = 63;
            this.label7.Text = "The ultimate family-friendly \r\nconsole featuring durable \r\nhardware and iconic, f" +
    "our \r\nplayer multiplayer classics \r\nlike Mario Kart.\r\n\r\n";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Courier New", 8F);
            this.label8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label8.Location = new System.Drawing.Point(1167, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(210, 70);
            this.label8.TabIndex = 64;
            this.label8.Text = "A versatile all-in-one \r\nentertainment hub that plays \r\nthousands of legendary ga" +
    "mes \r\nand doubles as a DVD player \r\nfor family movie nights.";
            // 
            // RetroRevival
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1394, 655);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnPlaceOrder);
            this.Controls.Add(this.btnNewOrder);
            this.Controls.Add(this.btnMarioKart);
            this.Controls.Add(this.btnPikmin);
            this.Controls.Add(this.btnSilentHill);
            this.Controls.Add(this.btnFinalFantasy);
            this.Controls.Add(this.btnSonic);
            this.Controls.Add(this.lblReceipt);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.txtResidentEvil);
            this.Controls.Add(this.lbl11);
            this.Controls.Add(this.lbl10);
            this.Controls.Add(this.txtSonic);
            this.Controls.Add(this.lbl9);
            this.Controls.Add(this.picResidentEvil);
            this.Controls.Add(this.picSonic);
            this.Controls.Add(this.lbl8);
            this.Controls.Add(this.txtAmtFinalFantasy);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.txtAmtSilentHill);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.picFinalFantasy);
            this.Controls.Add(this.picSilentHill);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.txtAmtPikmin);
            this.Controls.Add(this.btnResidentEvil);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.txtAmtMarioKart);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.picPikmin);
            this.Controls.Add(this.picMarioKart);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAmtDreamCast);
            this.Controls.Add(this.btnDreamCast);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAmtPS2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtAmtGameCube);
            this.Controls.Add(this.btnPS2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnGameCube);
            this.Controls.Add(this.lbl_dreamCastPrice);
            this.Controls.Add(this.lbl_dreamCast);
            this.Controls.Add(this.lbl_gmCubePrice);
            this.Controls.Add(this.lbl_gameCube);
            this.Controls.Add(this.lbl_ps2Price);
            this.Controls.Add(this.lbl_ps2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Name = "RetroRevival";
            this.Text = "RetroRevival";
            this.Load += new System.EventHandler(this.RetroRevival_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picResidentEvil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSonic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFinalFantasy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSilentHill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPikmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMarioKart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lbl_ps2Price;
        private System.Windows.Forms.Label lbl_ps2;
        private System.Windows.Forms.Label lbl_gameCube;
        private System.Windows.Forms.Label lbl_gmCubePrice;
        private System.Windows.Forms.Label lbl_dreamCast;
        private System.Windows.Forms.Label lbl_dreamCastPrice;
        private System.Windows.Forms.Button btnGameCube;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnPS2;
        private System.Windows.Forms.TextBox txtAmtGameCube;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAmtPS2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAmtDreamCast;
        private System.Windows.Forms.Button btnDreamCast;
        private System.Windows.Forms.PictureBox picMarioKart;
        private System.Windows.Forms.PictureBox picPikmin;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox txtAmtMarioKart;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.TextBox txtAmtPikmin;
        private System.Windows.Forms.Button btnResidentEvil;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.TextBox txtAmtFinalFantasy;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.TextBox txtAmtSilentHill;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.PictureBox picFinalFantasy;
        private System.Windows.Forms.PictureBox picSilentHill;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.TextBox txtResidentEvil;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.TextBox txtSonic;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.PictureBox picResidentEvil;
        private System.Windows.Forms.PictureBox picSonic;
        private System.Windows.Forms.Label lblReceipt;
        private System.Windows.Forms.Button btnSonic;
        private System.Windows.Forms.Button btnFinalFantasy;
        private System.Windows.Forms.Button btnSilentHill;
        private System.Windows.Forms.Button btnPikmin;
        private System.Windows.Forms.Button btnMarioKart;
        private System.Windows.Forms.Button btnNewOrder;
        private System.Windows.Forms.Button btnPlaceOrder;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

