﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Challenge
{
    public partial class RetroRevival : Form
    {
        const double TAX = .05; // Tax @ 5%

        // Prices of Game Consoles
        const double GAMECUBE = 175.99;
        const double DREAMCAST = 200.99;
        const double PS2 = 150.99;

        // Prices of Games
        const double SONIC = 49.99;
        const double MARIO = 64.99;
        const double SILENTHILL = 34.99;
        const double RESIDENTEVIL = 14.99;
        const double PIKMIN = 29.99;
        const double FINALFANTASY = 14.99;

        // Initializing Global Variables
        double totGameCube, totPS2, totDreamCast;
        double totFinalFantasy, totMarioKart, totSonic, totSilentHill, totResidentEvil, totPikmin;


        public RetroRevival()
        {
            InitializeComponent();
        }

        private void RetroRevival_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int amtGameCube = Convert.ToInt32(txtAmtGameCube.Text); // # of GameCubes

            // Enabling the GameCube pop-ups
            picMarioKart.Visible = 
            btnMarioKart.Visible =
            picPikmin.Visible = 
            btnPikmin.Visible =
            lbl1.Visible =
            lbl2.Visible =
            lbl3.Visible =
            lbl4.Visible =
            txtAmtMarioKart.Visible =
            txtAmtPikmin.Visible =
            btnPlaceOrder.Visible =
            true;

            // Disabling game console buttons
            btnPS2.Enabled =
            btnGameCube.Enabled =
            btnDreamCast.Enabled =
            false;

            totGameCube = amtGameCube * GAMECUBE; // Total for receipt

            lblReceipt.Text = String.Format("                Receipt\n" +
                                            "---------------------------------------------\n" + "Item          Qt          Cost          Total\n" +
                                            "GameCube      {0}         {1}       {2,-10}\n", amtGameCube, GAMECUBE.ToString("C"), totGameCube.ToString("C"));
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnPS2_Click(object sender, EventArgs e)
        {
            int amtPS2 = Convert.ToInt32(txtAmtPS2.Text); // # of PS2s

            // Enabling the PS2 pop-ups
            picSilentHill.Visible =
            btnSilentHill.Visible =
            picFinalFantasy.Visible =
            btnFinalFantasy.Visible =
            lbl5.Visible =
            lbl6.Visible =
            lbl7.Visible =
            lbl8.Visible =
            txtAmtFinalFantasy.Visible =
            txtAmtSilentHill.Visible =
            btnPlaceOrder.Visible =
            true;

            // Disabling game console buttons
            btnPS2.Enabled =
            btnGameCube.Enabled =
            btnDreamCast.Enabled =
            false;

            totPS2 = amtPS2 * PS2; // Total for receipt

            lblReceipt.Text = String.Format("                Receipt\n" +
                                            "---------------------------------------------\n" +
                                            "Item          Qt          Cost          Total\n" +
                                            "PlayStation 2 {0}         {1}       {2,-10}\n", amtPS2, PS2.ToString("C"), totPS2.ToString("C"));
        }               

        private void btnDreamCast_Click(object sender, EventArgs e)
        {
            int amtDreamCast = Convert.ToInt32(txtAmtDreamCast.Text); // # of DreamCasts

            // Enabling the DreamCast pop-ups
            picSonic.Visible =
            btnSonic.Visible =
            picResidentEvil.Visible =
            btnResidentEvil.Visible =
            lbl9.Visible =
            lbl10.Visible =
            lbl11.Visible =
            lbl12.Visible =
            txtSonic.Visible =
            txtResidentEvil.Visible =
            btnResidentEvil.Visible =
            btnPlaceOrder.Visible =
            true;

            // Disabling game console buttons
            btnPS2.Enabled =
            btnGameCube.Enabled =
            btnDreamCast.Enabled =
            false;

            totDreamCast = amtDreamCast * DREAMCAST; // Total for receipt

            lblReceipt.Text = String.Format("                Receipt\n" +
                                            "---------------------------------------------\n" + "Item          Qt          Cost          Total\n" +
                                            "DreamCast     {0}         {1}       {2,-10}\n", amtDreamCast, DREAMCAST.ToString("C"), totDreamCast.ToString("C"));
        }

        private void btnGamePurchase_Click(object sender, EventArgs e)
        {
            int amtResidentEvil = Convert.ToInt32(txtResidentEvil.Text); // # of Games
            totResidentEvil =  amtResidentEvil * RESIDENTEVIL; // Total for Receipt
            lblReceipt.Text += String.Format("Resident Evil {0}         {1}        {2,-10}\n", amtResidentEvil, RESIDENTEVIL.ToString("C"), totResidentEvil.ToString("C"));
            btnResidentEvil.Enabled = false;
        }

        private void btnMarioKart_Click(object sender, EventArgs e)
        {
            int amtMarioKart = Convert.ToInt32(txtAmtMarioKart.Text);
            totMarioKart = Convert.ToInt32(txtAmtMarioKart.Text) * MARIO;
            lblReceipt.Text += String.Format("MarioKart     {0}         {1}        {2,-10}\n", amtMarioKart, MARIO.ToString("C"), totMarioKart.ToString("C"));
            btnMarioKart.Enabled = false;
        }

        private void btnPikmin_Click(object sender, EventArgs e)
        {
            int amtPikmin = Convert.ToInt32(txtAmtPikmin.Text);
            totPikmin = Convert.ToInt32(txtAmtPikmin.Text) * PIKMIN;
            lblReceipt.Text += String.Format("Pikmin        {0}         {1}        {2,-10}\n", amtPikmin, PIKMIN.ToString("C"), totPikmin.ToString("C"));
            btnPikmin.Enabled = false;
        }

        private void btnSilentHill_Click(object sender, EventArgs e)
        {
            int amtSilentHill = Convert.ToInt32(txtAmtSilentHill.Text);
            totSilentHill = Convert.ToInt32(txtAmtSilentHill.Text) * SILENTHILL;
            lblReceipt.Text += String.Format("Silent Hill   {0}         {1}        {2,-10}\n", amtSilentHill, SILENTHILL.ToString("C"), totSilentHill.ToString("C"));
            btnSilentHill.Enabled = false;
        }

        private void btnSonic_Click(object sender, EventArgs e)
        {
            int amtSonic = Convert.ToInt32(txtSonic.Text);
            totSonic = Convert.ToInt32(txtSonic.Text) * SONIC;
            lblReceipt.Text += String.Format("Sonic         {0}         {1}        {2,-10}\n", amtSonic, SONIC.ToString("C"), totSonic.ToString("C"));
            btnSonic.Enabled = false;
        }

        private void btnFinalFantasy_Click(object sender, EventArgs e)
        {
            int amtFinalFantasy = Convert.ToInt32(txtAmtFinalFantasy.Text);
            totFinalFantasy = Convert.ToInt32(txtAmtFinalFantasy.Text) * FINALFANTASY;
            lblReceipt.Text += String.Format("Final Fantasy {0}         {1}        {2,-10}\n", amtFinalFantasy, FINALFANTASY.ToString("C"), totFinalFantasy.ToString("C"));
            btnFinalFantasy.Enabled = false;
        }

        private void btnNewOrder_Click(object sender, EventArgs e)
        {
            // Disabling all the pop-ups for a new order
            picMarioKart.Visible =
            btnMarioKart.Visible =
            picPikmin.Visible =
            btnPikmin.Visible =
            lbl1.Visible =
            lbl2.Visible =
            lbl3.Visible =
            lbl4.Visible =
            txtAmtMarioKart.Visible =
            txtAmtPikmin.Visible =
            btnNewOrder.Visible =
            picSilentHill.Visible =
            btnSilentHill.Visible =
            picFinalFantasy.Visible =
            btnFinalFantasy.Visible =
            lbl5.Visible =
            lbl6.Visible =
            lbl7.Visible =
            lbl8.Visible =
            txtAmtFinalFantasy.Visible =
            txtAmtSilentHill.Visible =
            picSonic.Visible =
            btnSonic.Visible =
            picResidentEvil.Visible =
            lbl9.Visible =
            lbl10.Visible =
            lbl11.Visible =
            lbl12.Visible =
            txtSonic.Visible =
            txtResidentEvil.Visible =
            btnResidentEvil.Visible =
            btnPlaceOrder.Visible =
            false;

            // Erasing the Receipt
            lblReceipt.Text = "";

            // Enabling all Buttons
            btnDreamCast.Enabled =
            btnPS2.Enabled =
            btnGameCube.Enabled =
            btnMarioKart.Enabled =
            btnFinalFantasy.Enabled =
            btnPikmin.Enabled =
            btnResidentEvil.Enabled =
            btnSonic.Enabled =
            btnSilentHill.Enabled =
            true;

            // Erasing all text in textboxes
            txtAmtDreamCast.Text =
            txtAmtFinalFantasy.Text =
            txtAmtGameCube.Text =
            txtAmtMarioKart.Text =
            txtAmtPikmin.Text =
            txtAmtPS2.Text =
            txtAmtSilentHill.Text =
            txtResidentEvil.Text =
            txtSonic.Text =
            "";

            // Setting all totals to 0 for correct math
            totDreamCast =
            totFinalFantasy =
            totGameCube =
            totMarioKart =
            totPikmin =
            totPS2 =
            totResidentEvil =
            totSilentHill =
            totSonic =
            0;
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            // Disable all buttons after placing order
            btnMarioKart.Enabled =
            btnFinalFantasy.Enabled =
            btnPikmin.Enabled =
            btnResidentEvil.Enabled =
            btnSonic.Enabled =
            btnSilentHill.Enabled =
            btnDreamCast.Enabled =
            btnPS2.Enabled =
            btnGameCube.Enabled =
            false;

            btnNewOrder.Visible = true; // After placing an order the user can start a new one
            // Add all of the totals up everywhere
            double subTotal = totFinalFantasy + totMarioKart + totPikmin + totResidentEvil + totSilentHill + totSonic + totDreamCast + totGameCube + totPS2;
            double taxTotal = subTotal * TAX;
            double grandTotal = subTotal + (subTotal * TAX);

            lblReceipt.Text += String.Format($"\n       Subtotal:    {subTotal.ToString("C"), 12}" +
                                             $"\n       Tax:         {taxTotal.ToString("C"), 12}" +
                                             $"\n       Grand Total: {grandTotal.ToString("C"), 12}");
        }
    }
}
